(function ($) {
    'use strict';


})(jQuery);